(function ($) {
    'use strict';


})(jQuery);